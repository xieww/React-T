export function addEventListener(node, event, listener) {
    if (node.addEventListener) {
        node.addEventListener(event, listener, false);
    } else {
        node.attachEvent('on' + event, listener);
    }
}

export function removeEventListener(node, event, listener) {
    if (node.removeEventListener) {
        node.removeEventListener(event, listener, false);
    } else {
        node.detachEvent('on' + event, listener);
    }
}
