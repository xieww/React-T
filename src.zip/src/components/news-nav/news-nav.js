import React from 'react';
import classNames from 'classnames';
import EditNav from '../edit-nav';

import './news-nav.less';

export default React.createClass({
    getInitialState() {

        // this.state = {};
        return {
            selectedItem: 0,
            editNavShowStatus: false
        };
    },

    /**
     * 
     * @param {*} evt 
     */
    closeEditNav(evt) {
        console.log(this);
        this.setState({
            editNavShowStatus: false
        });
    },

    /**
     * 
     * @param {*} evt 
     */
    editNav(evt) {
        this.setState({
            editNavShowStatus: true
        });
    },

    /**
     * 
     * @param {*} evt 
     * @param {*} idx 
     */
    changeNav(evt, idx) {
        this.setState({
            selectedItem: idx.substr(-1) - 0
        });  
    },

    /**
     * @desc hook
     *  this.props = {
     *      list: [], 
     *  }
     */
    render() {
        
        let listElement = this.props.list.map((item, index) => {

            return (
                <li key={index} 
                    className={classNames({'cur': index === this.state.selectedItem})}
                    onClick={this.changeNav}>{item.text}</li>
            );
        });
        return (
            <section className="news-nav">
                <ul>
                    {listElement}
                </ul>
                <span className="plus" onClick={this.editNav}>+</span>
                <EditNav status={this.state.editNavShowStatus} 
                        afterClose={this.closeEditNav} />
            </section>
        );
    },
});
