import React from 'react';
import classNames from 'classnames';
import './edit-nav.less';

export default React.createClass({
    close(evt) {
        this.props.afterClose && this.props.afterClose();
    },

    render() {

        return (
            <section className={classNames('edit-nav', {'show': this.props.status})}>这里是编辑菜单
                <div onClick={this.close}>x</div>
            </section>
        );
    },
});
