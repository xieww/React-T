import React from 'react';
import NewsHeader from '../news-header';
import NewsNav from '../news-nav';

import './App.less';

// const sss = React

export default React.createClass({
    render() {
        const navList = [
            {
                text: '推荐'
            }, {
                text: '健康'
            }, {
                text: '热点'
            }, {
                text: '汽车'
            }, {
                text: '社会'
            }, {
                text: '美食'
            }, {
                text: '科技'
            }, {
                text: '娱乐'
            }
        ];
        return (
            <section className="news">
                <NewsHeader className="header"></NewsHeader>
                <NewsNav className="nav" list={navList}></NewsNav>
                <div className="news-list">y</div>
            </section>
        );
    },
});
